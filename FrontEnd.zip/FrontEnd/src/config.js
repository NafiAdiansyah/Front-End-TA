const API_URL = "https://naffscg.my.id";
const WS_URL = "wss://naffscg.my.id";